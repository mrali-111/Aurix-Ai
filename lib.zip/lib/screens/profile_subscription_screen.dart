import 'dart:io';
import 'package:aurix_ai/screens/about_screen.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../update_service.dart';
import 'login_screen.dart';

class ProfileSubscriptionScreen extends StatefulWidget {
  const ProfileSubscriptionScreen({super.key});

  @override
  State<ProfileSubscriptionScreen> createState() =>
      _ProfileSubscriptionScreenState();
}

class _ProfileSubscriptionScreenState extends State<ProfileSubscriptionScreen>
    with TickerProviderStateMixin {
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;
  final _picker = ImagePicker();

  String _selectedPlan = 'FREE';
  String _photoUrl = '';
  String _localImagePath = '';
  bool _uploadingPhoto = false;

  final _oldPassCtrl = TextEditingController();
  final _newPassCtrl = TextEditingController();
  bool _showOld = false;
  bool _showNew = false;
  bool _passLoading = false;

  final String _whatsappNumber = '923011744430';
  final String _whatsappMessage =
      'I Have Palaced an order for *Aurix Ai* Here is my payment screenshot.';

  User? get _user => _auth.currentUser;

  String get _userEmail => _user?.email ?? 'user@aurix.app';

  String get _userName => _user?.displayName ?? _userEmail.split('@').first;

  void _startPlanListener() {
    if (_user == null) return;
    _firestore.collection('users').doc(_user!.uid).snapshots().listen((doc) {
      if (doc.exists && mounted) {
        setState(() {
          _selectedPlan = doc.data()?['plan'] ?? 'FREE';
          _photoUrl = doc.data()?['photoUrl'] ?? _user!.photoURL ?? '';
          _localImagePath = doc.data()?['localImagePath'] ?? '';
        });
      }
    });
  }

  @override
  void initState() {
    super.initState();
    _startPlanListener();
    _loadSavedImage();
    _checkForAppUpdate();
  }

  // Update check function
  void _checkForAppUpdate() async {
    final update = await UpdateService.checkForUpdate();
    if (update != null && mounted) {
      await UpdateService.showUpdateDialog(context, update);
    }
  }

  Future<void> _loadSavedImage() async {
    final prefs = await SharedPreferences.getInstance();
    final savedPath = prefs.getString('${_user?.uid}_profile_image') ?? '';
    if (savedPath.isNotEmpty && File(savedPath).existsSync()) {
      setState(() => _localImagePath = savedPath);
    }
  }

  @override
  void dispose() {
    _oldPassCtrl.dispose();
    _newPassCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickAndUploadImage() async {
    try {
      final XFile? picked = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
        maxWidth: 512,
      );
      if (picked == null) return;

      setState(() => _uploadingPhoto = true);

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('${_user?.uid}_profile_image', picked.path);

      await _firestore.collection('users').doc(_user!.uid).set({
        'localImagePath': picked.path,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      setState(() {
        _localImagePath = picked.path;
        _uploadingPhoto = false;
      });

      if (mounted) {
        _showSnack('✅ Profile Updated');
      }
    } catch (e) {
      if (mounted) setState(() => _uploadingPhoto = false);
      _showSnack('❌ Error: $e');
    }
  }

  Future<void> _changePassword() async {
    final oldPass = _oldPassCtrl.text.trim();
    final newPass = _newPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty) {
      _showSnack('⚠️ Fill All');
      return;
    }
    if (newPass.length < 6) {
      _showSnack('New Password 6 characters minimum');
      return;
    }

    setState(() => _passLoading = true);
    try {
      final cred =
      EmailAuthProvider.credential(email: _userEmail, password: oldPass);
      await _user!.reauthenticateWithCredential(cred);
      await _user!.updatePassword(newPass);
      setState(() => _passLoading = false);
      _oldPassCtrl.clear();
      _newPassCtrl.clear();
      _showSnack('✅ Password changed successfully!');
    } on FirebaseAuthException catch (e) {
      setState(() => _passLoading = false);
      _showSnack(e.code == 'wrong-password'
          ? '❌ Old password galat hai'
          : '❌ Error: ${e.message}');
    }
  }

  Future<void> _openWhatsApp() async {
    try {
      final message = Uri.encodeComponent(_whatsappMessage);
      final whatsappUrl = 'https://wa.me/$_whatsappNumber?text=$message';
      if (await canLaunchUrl(Uri.parse(whatsappUrl))) {
        await launchUrl(Uri.parse(whatsappUrl),
            mode: LaunchMode.externalApplication);
      } else {
        _showSnack('❌ WhatsApp not install');
      }
    } catch (e) {
      _showSnack('❌ Error: $e');
    }
  }

  Future<void> _submitPaymentRequest() async {
    try {
      await _firestore.collection('users').doc(_user!.uid).set(
        {
          'plan': 'PENDING',
          'paymentRequestedAt': FieldValue.serverTimestamp(),
          'paymentMethod': 'JazzCash',
          'paymentAmount': 200,
          'userEmail': _userEmail,
          'userName': _userName,
        },
        SetOptions(merge: true),
      );

      await _firestore.collection('payment_requests').add({
        'uid': _user!.uid,
        'email': _userEmail,
        'name': _userName,
        'plan': 'PREMIUM',
        'amount': 200,
        'method': 'JazzCash',
        'status': 'PENDING',
        'requestedAt': FieldValue.serverTimestamp(),
        'adminNote': '',
      });

      setState(() => _selectedPlan = 'PENDING');
      _showSnack('✅ Request submit! Contact on whatsapp.');
      await _openWhatsApp();
    } catch (e) {
      _showSnack('❌ Request fail.');
    }
  }

  void _logout() {
    showDialog(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Logout', style: TextStyle(fontWeight: FontWeight.w700)),
        content: const Text('Logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Color(0xFF999999))),
          ),
          TextButton(
            onPressed: () async {
              await _auth.signOut();
              if (mounted) {
                if (Navigator.canPop(context)) {
                  Navigator.pop(context);
                }
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const LoginScreen(),
                  ),
                );
              }
            },
            style: TextButton.styleFrom(
              foregroundColor: Colors.white,
              backgroundColor: Colors.red,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            child: const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Text('Logout', style: TextStyle(fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
    );
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.w600)),
      backgroundColor: const Color(0xFF7C4DFF),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F0ED),
      body: SingleChildScrollView(
        padding: const EdgeInsets.only(bottom: 100), // 50 se 100 kar do
        child: Column(
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            _buildPasswordCard(),
            const SizedBox(height: 20),
            _buildSubscriptionSection(),
            const SizedBox(height: 20),
            _buildContactSupport(),
            const SizedBox(height: 20),
            _buildAboutButton(),      // <--- YAHAN ADD KIYA
            const SizedBox(height: 20),
            _buildLogoutButton(),
            const SizedBox(height: 80), // 30 se 80 kar do
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    Color badgeColor;
    Color borderColor;
    String badgeText;

    if (_selectedPlan == 'PREMIUM') {
      badgeColor = Colors.amber.withOpacity(0.3);
      borderColor = Colors.amber;
      badgeText = '💎 Premium Member';
    } else if (_selectedPlan == 'PENDING') {
      badgeColor = Colors.orange.withOpacity(0.25);
      borderColor = Colors.orange;
      badgeText = '⏳ Verification Pending';
    } else {
      badgeColor = Colors.white.withOpacity(0.2);
      borderColor = Colors.white.withOpacity(0.5);
      badgeText = '🆓 Free Plan';
    }

    return Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF9C27B0), Color(0xFF7C4DFF), Color(0xFFFFB74D)],
          stops: [0.0, 0.5, 1.0],
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
          child: Column(
            children: [
              Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.arrow_back_ios_new,
                          color: Colors.white, size: 18),
                    ),
                  ),
                  const Expanded(
                    child: Text('My Profile',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.w700)),
                  ),
                  // Update Button - Top Right
                  GestureDetector(
                    onTap: () async {
                      final update = await UpdateService.checkForUpdate();
                      if (update != null && mounted) {
                        await UpdateService.showUpdateDialog(context, update);
                      } else if (mounted) {
                        _showSnack('✅ App is up to date!');
                      }
                    },
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.system_update_alt,
                          color: Colors.white, size: 20),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              GestureDetector(
                onTap: _pickAndUploadImage,
                child: Stack(
                  alignment: Alignment.bottomRight,
                  children: [
                    Container(
                      width: 90,
                      height: 90,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 3),
                      ),
                      child: ClipOval(
                        child: _uploadingPhoto
                            ? Container(
                          color: Colors.white24,
                          child: const Center(
                            child: SizedBox(
                              width: 28,
                              height: 28,
                              child: CircularProgressIndicator(
                                  color: Colors.white, strokeWidth: 2.5),
                            ),
                          ),
                        )
                            : _localImagePath.isNotEmpty &&
                            File(_localImagePath).existsSync()
                            ? Image.file(
                          File(_localImagePath),
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                          const _DefaultAvatar(),
                        )
                            : _photoUrl.isNotEmpty
                            ? Image.network(
                          _photoUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                          const _DefaultAvatar(),
                        )
                            : const _DefaultAvatar(),
                      ),
                    ),
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                              color: Colors.black.withOpacity(0.15),
                              blurRadius: 6)
                        ],
                      ),
                      child: const Icon(Icons.camera_alt_outlined,
                          size: 16, color: Color(0xFF7C4DFF)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              Text(_userName,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(_userEmail,
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.8), fontSize: 13)),
              const SizedBox(height: 12),
              Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                decoration: BoxDecoration(
                  color: badgeColor,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: borderColor, width: 1.2),
                ),
                child: Text(badgeText,
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 13)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPasswordCard() {
    return _sectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.lock_outline, 'Password Change'),
          const SizedBox(height: 6),
          const Text('Set a New Password',
              style: TextStyle(fontSize: 12, color: Color(0xFF888888))),
          const SizedBox(height: 16),
          _passField(
            ctrl: _oldPassCtrl,
            hint: 'Old password',
            icon: Icons.lock_outline,
            obscure: !_showOld,
            onToggle: () => setState(() => _showOld = !_showOld),
            visible: _showOld,
          ),
          const SizedBox(height: 12),
          _passField(
            ctrl: _newPassCtrl,
            hint: 'New password',
            icon: Icons.lock_open_outlined,
            obscure: !_showNew,
            onToggle: () => setState(() => _showNew = !_showNew),
            visible: _showNew,
          ),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: _passLoading ? null : _changePassword,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    colors: [Color(0xFF9C27B0), Color(0xFF7C4DFF)]),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0xFF7C4DFF).withOpacity(0.3),
                      blurRadius: 12,
                      offset: const Offset(0, 4))
                ],
              ),
              child: _passLoading
                  ? const Center(
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                      color: Colors.white, strokeWidth: 2),
                ),
              )
                  : const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.save_outlined,
                      color: Colors.white, size: 18),
                  SizedBox(width: 8),
                  Text('Change Password',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 14)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _passField({
    required TextEditingController ctrl,
    required String hint,
    required IconData icon,
    required bool obscure,
    required VoidCallback onToggle,
    required bool visible,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF7F7F7),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE0E0E0), width: 1.2),
      ),
      child: TextField(
        controller: ctrl,
        obscureText: obscure,
        style: const TextStyle(fontSize: 14, color: Color(0xFF333333)),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: Color(0xFFAAAAAA), fontSize: 13),
          prefixIcon: Icon(icon, color: const Color(0xFF7C4DFF), size: 20),
          suffixIcon: GestureDetector(
            onTap: onToggle,
            child: Padding(
              padding: const EdgeInsets.only(right: 12),
              child: Icon(
                visible
                    ? Icons.visibility_outlined
                    : Icons.visibility_off_outlined,
                color: const Color(0xFF999999),
                size: 20,
              ),
            ),
          ),
          border: InputBorder.none,
          contentPadding:
          const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        ),
      ),
    );
  }

  Widget _buildSubscriptionSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 4, bottom: 12),
            child: Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: const Color(0xFF7C4DFF).withOpacity(0.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.workspace_premium_outlined,
                      color: Color(0xFF7C4DFF), size: 18),
                ),
                const SizedBox(width: 8),
                const Text('Manage Subscription',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF1A1A1A))),
              ],
            ),
          ),
          if (_selectedPlan == 'PENDING') ...[
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF8E1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                    color: Colors.orange.withOpacity(0.4), width: 1.2),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text('⏳', style: TextStyle(fontSize: 22)),
                      SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Send Payment Screenshot',
                                style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 13,
                                    color: Color(0xFFE65100))),
                            SizedBox(height: 3),
                            Text(
                                'Admin manually verification.Follow up on WhatsApp.',
                                style: TextStyle(
                                    fontSize: 12,
                                    color: Color(0xFF795548))),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
          _planCard(
            isPremium: false,
            isSelected: _selectedPlan == 'FREE',
            title: 'Free Plan',
            price: 'Rs 0 / forever',
            features: [

              '🔔 3 Active reminders',
              '📰 Basic news (1 update/day)',
              '🎤 Unlimited voice input',
              '🖼️ 5 Image generations (trial)',
            ],
            onTap: (_selectedPlan == 'PENDING' || _selectedPlan == 'PREMIUM')
                ? null
                : () async {
              await _firestore
                  .collection('users')
                  .doc(_user!.uid)
                  .set({'plan': 'FREE'}, SetOptions(merge: true));
              setState(() => _selectedPlan = 'FREE');
            },
          ),
          const SizedBox(height: 12),
          _planCard(
            isPremium: true,
            isSelected: _selectedPlan == 'PREMIUM',
            isPending: _selectedPlan == 'PENDING',
    title: 'Premium Plan',
    price: 'Rs 200 / month',
    features: [
    '🚀 Unlimited AI messages',
    '⏰ Unlimited reminders & alerts',
    '📰 Live news (real-time)',
    '🎙️ Full voice support',
    '🖼️ Unlimited image generation',
    '📰 Daily All World Stories',
    '⭐ Priority customer support',
    '🔒 Ad-free experience',
    ],
            onTap: (_selectedPlan == 'PREMIUM' || _selectedPlan == 'PENDING')
                ? null
                : _showQrDialog,
          ),
        ],
      ),
    );
  }

  void _showQrDialog() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.6),
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(28),
            boxShadow: [
              BoxShadow(
                  color: const Color(0xFF7C4DFF).withOpacity(0.3),
                  blurRadius: 40,
                  offset: const Offset(0, 12))
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [Color(0xFF9C27B0), Color(0xFF7C4DFF)]),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text('💎 Premium — Rs 200',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                        fontSize: 15)),
              ),
              const SizedBox(height: 18),
              const Text(
                'Send Payment',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 13, color: Color(0xFF555555), height: 1.5),
              ),
              const SizedBox(height: 16),
              Image.asset('assets/Qr.png',
                  width: 120, height: 120, fit: BoxFit.contain),
              const SizedBox(height: 5),
              const Text('JazzCash QR',
                  style: TextStyle(
                      fontSize: 13,
                      color: Color(0xFF666666),
                      fontWeight: FontWeight.w600)),
              const SizedBox(height: 16),
              const Text('Jazzcash Number\n03011744430',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 13, color: Color(0xFF555555), height: 1.5)),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF3E0),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.orange.withOpacity(0.4)),
                ),
                child: const Text(
                  '⚠️After Send Payment\n"Contact with admin',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 11,
                      color: Color(0xFFE65100),
                      fontWeight: FontWeight.w600),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF0F0F0),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Text('Cancel',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: Color(0xFF555555),
                                fontWeight: FontWeight.w700,
                                fontSize: 14)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                        _submitPaymentRequest();
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 13),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [
                            Color(0xFF9C27B0),
                            Color(0xFF7C4DFF)
                          ]),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Text('Payment Success ✓',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                                fontSize: 13)),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _planCard({
    required bool isPremium,
    required bool isSelected,
    bool isPending = false,
    required String title,
    required String price,
    required List<String> features,
    VoidCallback? onTap,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: isPremium
            ? const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF9C27B0),
            Color(0xFF7C4DFF),
            Color(0xFFFFB74D)
          ],
          stops: [0.0, 0.5, 1.0],
        )
            : null,
        border: !isPremium
            ? Border.all(
            color: isSelected
                ? const Color(0xFF7C4DFF)
                : const Color(0xFFDDDDDD),
            width: 2)
            : null,
        boxShadow: isPremium
            ? [
          BoxShadow(
              color: const Color(0xFF7C4DFF).withOpacity(0.3),
              blurRadius: 20,
              offset: const Offset(0, 8))
        ]
            : [],
      ),
      child: Container(
        margin: isPremium ? const EdgeInsets.all(1.8) : EdgeInsets.zero,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: isPremium ? Colors.white.withOpacity(0.92) : Colors.white,
          borderRadius: BorderRadius.circular(isPremium ? 23 : 22),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Text(isPremium ? '💎' : '🆓',
                        style: const TextStyle(fontSize: 20)),
                    const SizedBox(width: 8),
                    Text(title,
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                            color: isPremium
                                ? const Color(0xFF7C4DFF)
                                : const Color(0xFF1A1A1A))),
                  ],
                ),
                if (isSelected)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFF4CAF50).withOpacity(0.12),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text('✓ Active',
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF4CAF50))),
                  ),
                if (isPending && isPremium)
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.orange.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text('⏳ Pending',
                        style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Colors.orange)),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            Text(price,
                style: TextStyle(
                    fontSize: 13,
                    color: isPremium
                        ? const Color(0xFF9C27B0)
                        : const Color(0xFF888888),
                    fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            ...features.map((f) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                children: [
                  Icon(Icons.check_circle_outline,
                      size: 15,
                      color: isPremium
                          ? const Color(0xFF7C4DFF)
                          : const Color(0xFF4CAF50)),
                  const SizedBox(width: 6),
                  Text(f,
                      style: const TextStyle(
                          fontSize: 12, color: Color(0xFF444444))),
                ],
              ),
            )),
            if (!isSelected && !isPending && onTap != null) ...[
              const SizedBox(height: 14),
              GestureDetector(
                onTap: onTap,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  decoration: BoxDecoration(
                    gradient: isPremium
                        ? const LinearGradient(
                        colors: [Color(0xFF9C27B0), Color(0xFF7C4DFF)])
                        : null,
                    color: isPremium ? null : const Color(0xFFF0F0F0),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: isPremium
                        ? [
                      const Icon(Icons.qr_code_scanner,
                          color: Colors.white, size: 18),
                      const SizedBox(width: 8),
                      const Text('Buy Now',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 13)),
                    ]
                        : [
                      const Text('Select Free Plan',
                          style: TextStyle(
                              color: Color(0xFF555555),
                              fontWeight: FontWeight.w600,
                              fontSize: 13)),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildContactSupport() {
    return _sectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.support_agent_outlined, 'Contact Support'),
          const SizedBox(height: 4),
          const Text('Share Your Problems',
              style: TextStyle(fontSize: 12, color: Color(0xFF888888))),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF25D366), Color(0xFF128C7E)],
                stops: [0.0, 1.0],
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                    color: const Color(0xFF25D366).withOpacity(0.3),
                    blurRadius: 20,
                    offset: const Offset(0, 8))
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Text('💬', style: TextStyle(fontSize: 24)),
                    SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('WhatsApp Support',
                              style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 15,
                                  color: Colors.white)),
                          SizedBox(height: 2),
                          Text('Direct chat with admin',
                              style: TextStyle(
                                  fontSize: 12, color: Colors.white70)),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                GestureDetector(
                  onTap: _openWhatsApp,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 13),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.95),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.message_rounded,
                            color: Color(0xFF25D366), size: 20),
                        SizedBox(width: 8),
                        Text('Open WhatsApp',
                            style: TextStyle(
                                color: Color(0xFF25D366),
                                fontWeight: FontWeight.w700,
                                fontSize: 14)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFF0F0F0),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.lightGreen),
            ),
            child: const Text(
              '📞 Contact: Whatsapp\n\n'
                  'Now Share All Problems.',
              style: TextStyle(
                  fontSize: 12, color: Color(0xFF555555), height: 1.6),
            ),
          ),
        ],
      ),
    );
  }
  Widget _buildAboutButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AboutScreen()),
          );
        },
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFF7C4DFF).withOpacity(0.3), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF7C4DFF).withOpacity(0.08),
                blurRadius: 16,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.info_outline, color: Color(0xFF7C4DFF), size: 20),
              SizedBox(width: 10),
              Text(
                'About Aurix AI',
                style: TextStyle(
                  color: Color(0xFF7C4DFF),
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  Widget _buildLogoutButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GestureDetector(
        onTap: _logout,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border:
            Border.all(color: Colors.red.withOpacity(0.3), width: 1.5),
            boxShadow: [
              BoxShadow(
                  color: Colors.red.withOpacity(0.08),
                  blurRadius: 16,
                  offset: const Offset(0, 4))
            ],
          ),
          child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.logout_rounded, color: Colors.red, size: 20),
              SizedBox(width: 10),
              Text('Logout',
                  style: TextStyle(
                      color: Colors.red,
                      fontSize: 15,
                      fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionCard({required Widget child}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF9C27B0), Color(0xFF7C4DFF), Color(0xFFFFB74D)],
            stops: [0.0, 0.5, 1.0],
          ),
          boxShadow: [
            BoxShadow(
                color: const Color(0xFF7C4DFF).withOpacity(0.2),
                blurRadius: 24,
                offset: const Offset(0, 8))
          ],
        ),
        child: Container(
          margin: const EdgeInsets.all(1.8),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.92),
            borderRadius: BorderRadius.circular(23),
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _sectionTitle(IconData icon, String title) {
    return Row(
      children: [
        Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: const Color(0xFF7C4DFF).withOpacity(0.12),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: const Color(0xFF7C4DFF), size: 17),
        ),
        const SizedBox(width: 8),
        Text(title,
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Color(0xFF1A1A1A))),
      ],
    );
  }
}

class _DefaultAvatar extends StatelessWidget {
  const _DefaultAvatar();
  @override
  Widget build(BuildContext context) => Container(
    color: Colors.white24,
    child: const Icon(Icons.person, size: 50, color: Colors.white),
  );
}
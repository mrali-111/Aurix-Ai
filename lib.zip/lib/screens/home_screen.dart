import 'package:aurix_ai/screens/success_screen.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'ai_assistant_screen.dart' hide ImageProvider;
import 'task_model.dart';
import 'reminder_screen.dart';
import 'package:aurix_ai/screens/profile_subscription_screen.dart';
import 'package:xml/xml.dart';
import 'package:image_picker/image_picker.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;

  int _selectedIndex = 0;
  late Timer _timeTimer;
  late Timer _quoteTimer;
  late Timer _newsTimer;
  String _currentTime = '';
  String _currentDate = '';
  String _currentQuote = '"Every day is a new chance to grow stronger. 🌿"';
  List<Map<String, String>> _newsArticles = [];
  int _currentQuoteIndex = 0;
  String _userPlan = 'FREE';
  String? _profileImagePath;

  List<TaskModel> _tasks = [];

  final List<String> _quotes = [
    '"Every day is a new chance to grow stronger. 🌿"',
    '"Success is the sum of small efforts repeated day in and day out. 💪"',
    '"Your potential is endless. Keep pushing forward. ⭐"',
    '"Great things never came from comfort zones. 🚀"',
    '"Believe in yourself and you are halfway there. 💖"',
    '"Progress, not perfection. Keep going! 🎯"',
  ];

  User? get _user => _auth.currentUser;

  @override
  void initState() {
    super.initState();
    _loadProfileImage();
    _loadQuoteIndex();
    _updateTime();
    _setupTimers();
    _fetchNews();
    _loadTasks();
    _startPlanListener();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path = prefs.getString('${_auth.currentUser?.uid}_profile_image') ?? '';
    if (mounted) {
      setState(() {
        _profileImagePath = path.isNotEmpty ? path : null;
      });
    }
  }

  ImageProvider? _getProfileImage() {
    if (_profileImagePath != null && _profileImagePath!.isNotEmpty) {
      return FileImage(File(_profileImagePath!));
    }
    if (_user?.photoURL != null && _user!.photoURL!.isNotEmpty) {
      return NetworkImage(_user!.photoURL!);
    }
    return null;
  }

  Future<void> _loadQuoteIndex() async {
    final prefs = await SharedPreferences.getInstance();
    final savedIndex = prefs.getInt('quote_index') ?? 0;
    final lastUpdate = prefs.getString('quote_last_update');

    if (lastUpdate != null) {
      final lastDate = DateTime.parse(lastUpdate);
      final hoursPassed = DateTime.now().difference(lastDate).inHours;
      if (hoursPassed >= 12) {
        final newIndex = (savedIndex + 1) % _quotes.length;
        setState(() {
          _currentQuoteIndex = newIndex;
          _currentQuote = _quotes[newIndex];
        });
        await _saveQuoteIndex(newIndex);
      } else {
        setState(() {
          _currentQuoteIndex = savedIndex;
          _currentQuote = _quotes[savedIndex];
        });
      }
    } else {
      setState(() {
        _currentQuoteIndex = savedIndex;
        _currentQuote = _quotes[savedIndex];
      });
    }
  }

  Future<void> _saveQuoteIndex(int index) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('quote_index', index);
    await prefs.setString('quote_last_update', DateTime.now().toIso8601String());
  }

  void _startPlanListener() {
    if (_user == null) return;
    _firestore.collection('users').doc(_user!.uid).snapshots().listen((doc) {
      if (doc.exists && mounted) {
        setState(() {
          _userPlan = doc.data()?['plan'] ?? 'FREE';
        });
      }
    });
  }

  void _setupTimers() {
    _timeTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _updateTime();
      if (mounted) setState(() {});
    });

    _quoteTimer = Timer.periodic(const Duration(hours: 12), (_) {
      if (mounted) {
        final newIndex = (_currentQuoteIndex + 1) % _quotes.length;
        setState(() {
          _currentQuoteIndex = newIndex;
          _currentQuote = _quotes[newIndex];
        });
        _saveQuoteIndex(newIndex);
      }
    });

    _newsTimer = Timer.periodic(const Duration(hours: 6), (_) {
      _fetchNews();
    });
  }

  void _updateTime() {
    final now = DateTime.now();
    _currentTime = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';
    _currentDate = now.hour < 12 ? 'AM' : 'PM';
  }

  Future<void> _loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    final tRaw = prefs.getStringList('tasks') ?? [];
    if (mounted) {
      setState(() {
        _tasks = tRaw.map((e) => TaskModel.fromJson(jsonDecode(e))).toList();
      });
    }
  }

  void _onTasksChanged(List<TaskModel> updated) {
    if (mounted) setState(() => _tasks = updated);
  }

  Future<void> _fetchNews() async {
    const String rssUrl = 'https://news.google.com/rss/search?q=pakistan+today&hl=en-PK&gl=PK&ceid=PK:en';

    try {
      final response = await http
          .get(Uri.parse(rssUrl), headers: {'User-Agent': 'Mozilla/5.0'})
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200 && mounted) {
        final document = XmlDocument.parse(response.body);
        final int itemCount = (_userPlan == 'PREMIUM') ? 3 : 1;
        final items = document.findAllElements('item').take(itemCount).toList();
        final List<Map<String, String>> fetched = [];

        for (final item in items) {
          final title = item.findElements('title').firstOrNull?.innerText ?? 'News';
          String source = 'Google News';
          final sourceEl = item.findElements('source').firstOrNull;
          if (sourceEl != null) source = sourceEl.innerText;
          String desc = item.findElements('description').firstOrNull?.innerText ?? '';
          desc = desc.replaceAll(RegExp(r'<[^>]*>'), '').replaceAll('&nbsp;', ' ').replaceAll('&amp;', '&').replaceAll('&lt;', '<').replaceAll('&gt;', '>').trim();
          if (desc.isEmpty) desc = 'Tap to read full story';
          fetched.add({'title': title, 'description': desc, 'source': source});
        }

        if (fetched.isNotEmpty && mounted) {
          setState(() => _newsArticles = fetched);
        }
      }
    } catch (e) {
      if (_newsArticles.isEmpty && mounted) {
        setState(() {
          _newsArticles = [
            {'title': 'Pakistan Today Headlines', 'description': 'Connect Internet', 'source': 'Google News'}
          ];
        });
      }
    }
  }

  @override
  void dispose() {
    _timeTimer.cancel();
    _quoteTimer.cancel();
    _newsTimer.cancel();
    super.dispose();
  }

  void _openReminder() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ReminderScreen(onTasksChanged: _onTasksChanged)))
        .then((_) {
      _loadTasks();
      if (mounted) setState(() => _selectedIndex = 0);
    });
  }

  void _openAIAssistant() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const AIAssistantScreen()))
        .then((_) {
      if (mounted) setState(() => _selectedIndex = 0);
    });
  }

  void _openProfile() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileSubscriptionScreen()))
        .then((_) {
      _loadProfileImage();
      if (mounted) {
        setState(() => _selectedIndex = 0);
        _fetchNews();
      }
    });
  }

  void _openSuccess() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const SuccessScreen()))
        .then((_) {
      if (mounted) setState(() => _selectedIndex = 0);
    });
  }

  Widget _buildBody() {
    switch (_selectedIndex) {
      case 0: return _buildHomeContent();
      case 1: return _buildHomeContent();
      case 2: return _buildHomeContent();
      case 3: return const SuccessScreen();
      case 4: return _buildHomeContent();
      default: return _buildHomeContent();
    }
  }

  Widget _buildHomeContent() {
    final size = MediaQuery.of(context).size;
    return SafeArea(
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.only(bottom: 20),  // bottom padding kam kar diya kyunki navbar ab bottomNavigationBar hai
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            _buildTopBar(),
            const SizedBox(height: 24),
            _buildQuoteSection(size),
            const SizedBox(height: 20),
            _buildNewsCards(),
            const SizedBox(height: 20),
            _buildReminderCard(),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F0ED),
      body: _buildBody(),
      bottomNavigationBar: _buildBottomNav(),  // ✅ FIXED: bottomNavigationBar use kiya (Stack se hataya)
    );
  }

  Widget _buildTopBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          const Expanded(
            child: Text(
              'How Are You?',
              style: TextStyle(
                fontFamily: 'Georgia',
                fontSize: 30,
                fontStyle: FontStyle.italic,
                fontWeight: FontWeight.w700,
                color: Color(0xFF1A1A1A),
                height: 1.2,
              ),
            ),
          ),
          GestureDetector(
            onTap: _openProfile,
            child: CircleAvatar(
              radius: 21,
              backgroundColor: const Color(0xFF7C4DFF),
              backgroundImage: _getProfileImage(),
              child: _getProfileImage() == null
                  ? const Icon(Icons.person, color: Colors.white, size: 15)
                  : null,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuoteSection(Size size) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        width: double.infinity,
        height: 170,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          image: const DecorationImage(
            image: AssetImage('assets/12.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Text(
                _currentQuote,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: 'Georgia',
                  fontSize: 20,
                  fontStyle: FontStyle.italic,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                  height: 1.5,
                  shadows: [
                    Shadow(color: Colors.white.withOpacity(0.8), blurRadius: 8),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNewsCards() {
    final List<List<Color>> cardGradients = [
      [const Color(0xFF6A1B9A), const Color(0xFFAB47BC)],
      [const Color(0xFF1565C0), const Color(0xFF42A5F5)],
      [const Color(0xFFE65100), const Color(0xFFFFB300)],
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Today News - Live Daily Updates',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Color(0xFF1A1A1A)),
          ),
          const SizedBox(height: 12),
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF9C27B0), Color(0xFF7C4DFF), Color(0xFFFFB74D)],
                stops: [0.0, 0.5, 1.0],
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0x337C4DFF),
                  blurRadius: 24,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Container(
              margin: const EdgeInsets.all(1.8),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.88),
                borderRadius: BorderRadius.circular(23),
              ),
              child: _newsArticles.isEmpty
                  ? const Center(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Color(0xFF7C4DFF),
                    ),
                  ),
                ),
              )
                  : Column(
                children: List.generate(_newsArticles.length, (i) {
                  final article = _newsArticles[i];
                  final colors = cardGradients[i % cardGradients.length];
                  return Container(
                    margin: EdgeInsets.only(bottom: i < _newsArticles.length - 1 ? 12 : 0),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: colors,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: colors[0].withOpacity(0.4),
                          blurRadius: 12,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Icon(Icons.newspaper_outlined, size: 20, color: Colors.white),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                article['title']!,
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          article['description']!,
                          style: TextStyle(
                            fontSize: 11,
                            color: Colors.white.withOpacity(0.88),
                            height: 1.4,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            const Icon(Icons.circle, size: 6, color: Colors.white70),
                            const SizedBox(width: 5),
                            Text(
                              article['source']!,
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.white.withOpacity(0.75),
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                }),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReminderCard() {
    final upcoming = _tasks
        .where((t) => t.taskDateTime.isAfter(DateTime.now()))
        .take(2)
        .toList();

    return GestureDetector(
      onTap: _openReminder,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF9C27B0), Color(0xFF7C4DFF), Color(0xFFFFB74D)],
              stops: [0.0, 0.5, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0x337C4DFF),
                blurRadius: 24,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Container(
            margin: const EdgeInsets.all(1.8),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.88),
              borderRadius: BorderRadius.circular(23),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(23),
              child: Stack(
                children: [
                  Positioned(
                    right: -30,
                    top: -30,
                    child: Container(
                      width: 120,
                      height: 120,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFF9C27B0).withOpacity(0.07),
                      ),
                    ),
                  ),
                  Positioned(
                    right: 30,
                    bottom: -20,
                    child: Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFFFFB74D).withOpacity(0.12),
                      ),
                    ),
                  ),
                  Positioned(
                    left: -20,
                    bottom: -25,
                    child: Container(
                      width: 90,
                      height: 90,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFF7C4DFF).withOpacity(0.07),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 80,
                    top: 10,
                    child: Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: const Color(0xFFFFB74D).withOpacity(0.10),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Container(
                                  width: 30,
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF4CAF50).withOpacity(0.13),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Icon(
                                    Icons.check_circle_outline,
                                    color: Color(0xFF4CAF50),
                                    size: 19,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                const Text(
                                  'Reminder',
                                  style: TextStyle(
                                    fontSize: 17,
                                    fontWeight: FontWeight.w700,
                                    color: Color(0xFF1A1A1A),
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              children: [
                                Container(
                                  width: 30,
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF7C4DFF).withOpacity(0.10),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Icon(
                                    Icons.alarm_outlined,
                                    color: Color(0xFF7C4DFF),
                                    size: 18,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                if (_tasks.isNotEmpty)
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF7C4DFF).withOpacity(0.12),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Text(
                                      '${_tasks.length} Tasks',
                                      style: const TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                        color: Color(0xFF7C4DFF),
                                      ),
                                    ),
                                  ),
                                const SizedBox(width: 6),
                                const Icon(Icons.chevron_right, color: Color(0xFF999999), size: 20),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 14),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'Remaining Tasks',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Color(0xFF888888),
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  if (upcoming.isEmpty)
                                    _taskRow(
                                      icon: Icons.add_ic_call_outlined,
                                      iconBg: const Color(0xFFE8F5E9),
                                      iconColor: const Color(0xFF4CAF50),
                                      title: 'No Task',
                                      subtitle: 'Reminder add  →',
                                    )
                                  else
                                    ...upcoming.map((t) {
                                      final diff = t.taskDateTime.difference(DateTime.now());
                                      final isOverdue = diff.isNegative;

                                      String timeLeft;
                                      if (isOverdue) {
                                        timeLeft = 'Waqt aa gaya! ⚡';
                                      } else if (diff.inHours > 0) {
                                        timeLeft = '${diff.inHours}h ${diff.inMinutes % 60}m ${diff.inSeconds % 60}s baki';
                                      } else if (diff.inMinutes > 0) {
                                        timeLeft = '${diff.inMinutes}m ${diff.inSeconds % 60}s baki';
                                      } else {
                                        timeLeft = '${diff.inSeconds}s baki';
                                      }

                                      final Color taskColor = isOverdue
                                          ? Colors.red
                                          : diff.inMinutes < 10
                                          ? Colors.red
                                          : diff.inMinutes < 60
                                          ? Colors.orange
                                          : const Color(0xFF4CAF50);

                                      return Padding(
                                        padding: const EdgeInsets.only(bottom: 10),
                                        child: _taskRow(
                                          icon: Icons.alarm,
                                          iconBg: taskColor.withOpacity(0.12),
                                          iconColor: taskColor,
                                          title: t.name,
                                          subtitle: timeLeft,
                                        ),
                                      );
                                    }),
                                ],
                              ),
                            ),
                            const SizedBox(width: 12),
                            Builder(builder: (_) {
                              final nextTask = _tasks
                                  .where((t) => t.taskDateTime.isAfter(DateTime.now()))
                                  .toList()
                                ..sort((a, b) => a.taskDateTime.compareTo(b.taskDateTime));
                              final hasTask = nextTask.isNotEmpty;

                              String taskCountdown = '';
                              Color countdownColor = const Color(0xFF4CAF50);
                              if (hasTask) {
                                final diff = nextTask.first.taskDateTime.difference(DateTime.now());
                                if (diff.isNegative) {
                                  taskCountdown = 'Waqt!';
                                  countdownColor = Colors.red;
                                } else if (diff.inHours > 0) {
                                  taskCountdown = '${diff.inHours}h ${diff.inMinutes % 60}m';
                                  countdownColor = const Color(0xFF4CAF50);
                                } else if (diff.inMinutes >= 10) {
                                  taskCountdown = '${diff.inMinutes}m ${diff.inSeconds % 60}s';
                                  countdownColor = Colors.orange;
                                } else {
                                  taskCountdown = '${diff.inMinutes}m ${diff.inSeconds % 60}s';
                                  countdownColor = Colors.red;
                                }
                              }

                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  if (hasTask) ...[
                                    Text(
                                      'Task Baki',
                                      style: TextStyle(
                                        fontSize: 10,
                                        color: countdownColor,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    const SizedBox(height: 3),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                                      decoration: BoxDecoration(
                                        color: countdownColor.withOpacity(0.13),
                                        borderRadius: BorderRadius.circular(10),
                                        border: Border.all(
                                          color: countdownColor.withOpacity(0.35),
                                          width: 1.2,
                                        ),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(Icons.timer_outlined, size: 14, color: countdownColor),
                                          const SizedBox(width: 4),
                                          Text(
                                            taskCountdown,
                                            style: TextStyle(
                                              fontFamily: 'Courier',
                                              fontSize: 15,
                                              fontWeight: FontWeight.bold,
                                              color: countdownColor,
                                              letterSpacing: 1,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ] else ...[
                                    Text(
                                      _currentDate,
                                      style: const TextStyle(
                                        fontSize: 11,
                                        color: Color(0xFF999999),
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                  const SizedBox(height: 6),
                                  const Text(
                                    'Time',
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: Color(0xFF888888),
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF1A1A2E),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Text(
                                      _currentTime,
                                      style: const TextStyle(
                                        fontFamily: 'Courier',
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xFF00FF88),
                                        letterSpacing: 1,
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            }),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _taskRow({
    required IconData icon,
    required Color iconBg,
    required Color iconColor,
    required String title,
    required String subtitle,
  }) {
    return Row(
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: iconBg,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: iconColor, size: 18),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF333333),
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                subtitle,
                style: const TextStyle(fontSize: 10, color: Color(0xFF888888)),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ✅ FIXED: Bottom Navigation Bar - Ab koi overflow nahi, koi jumping nahi
  Widget _buildBottomNav() {
    return Container(
      height: 70,  // fixed height
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 15,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _NavItem(
            icon: Icons.home_outlined,
            label: 'Home',
            selected: _selectedIndex == 0,
            onTap: () {
              if (mounted) setState(() => _selectedIndex = 0);
            },
          ),
          _NavItem(
            icon: Icons.alarm_outlined,
            label: 'Reminder',
            selected: _selectedIndex == 1,
            onTap: () {
              if (mounted) setState(() => _selectedIndex = 1);
              _openReminder();
            },
          ),
          GestureDetector(
            onTap: _openAIAssistant,
            child: Container(
              margin: const EdgeInsets.only(bottom: 0),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Color(0xFF7C4DFF),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x557C4DFF),
                          blurRadius: 16,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 44,
                    height: 44,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF9C27B0), Color(0xFF7C4DFF)],
                      ),
                    ),
                    child: const Icon(Icons.mic, color: Colors.white, size: 22),
                  ),
                ],
              ),
            ),
          ),
          _NavItem(
            icon: Icons.emoji_events_outlined,
            label: 'Success',
            selected: _selectedIndex == 3,
            onTap: () {
              if (mounted) setState(() => _selectedIndex = 3);
              _openSuccess();
            },
          ),
          _NavItem(
            icon: Icons.person_outline,
            label: 'Profile',
            selected: _selectedIndex == 4,
            onTap: () {
              if (mounted) setState(() => _selectedIndex = 4);
              _openProfile();
            },
          ),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _NavItem({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(30),
      child: Container(
        width: 60,
        height: 60,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 24,
              color: selected ? const Color(0xFF7C4DFF) : const Color(0xFF999999),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w500,
                color: selected ? const Color(0xFF7C4DFF) : const Color(0xFF999999),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
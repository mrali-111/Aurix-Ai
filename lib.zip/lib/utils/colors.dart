import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF0F172A); // Dark Blue
  static const Color secondary = Color(0xFF1E293B);
  static const Color accent = Color(0xFF38BDF8);
  static const Color white = Colors.white;
}